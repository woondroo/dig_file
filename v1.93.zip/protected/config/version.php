<?php
define( 'CUR_VERSION' , '1.93' );
?>
